create definer = root@localhost trigger change_rank
    after update
    on submit
    for each row
begin
        declare _rank varchar(1000);
        declare _left varchar(2000);
        declare str varchar(1000);
        set _rank = (select rank from `rank` where id=1);
        if new.result != 0 and new.result != 1 then
            set str = substring_index(_rank, '\'is_ac\': ', -1);
            if substring_index(str, ',', 1) != 'True' then
            begin
                declare wrongTime varchar(100);
                declare t varchar(100);
                declare _right varchar(2000);
                set t = substring_index(str, '\'wrongTime\': ', -1);
                set _left = substring_index(_rank, t, 1);
                set _right = substring_index(t, ',', -1);
                set wrongTime = substring_index(t, ',', 1);
                set wrongTime = cast((cast(wrongTime as signed) + 1) as char(10));
                update `rank` set rank = concat(_left, wrongTime, ',', _right);
            end;
            end if;
        end if;
    end;

